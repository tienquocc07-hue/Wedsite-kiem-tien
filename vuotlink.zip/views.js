'use strict';

class Raw {
  constructor(v) { this.v = v; }
}
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
const part = (v) => (v instanceof Raw ? v.v : Array.isArray(v) ? v.map(part).join('') : esc(v));
const h = (strings, ...vals) => new Raw(strings.reduce((out, s, i) => out + s + (i < vals.length ? part(vals[i]) : ''), ''));
const send = (res, page, status = 200) => res.status(status).type('html').send(page.v);

const TZ = { timeZone: 'Asia/Ho_Chi_Minh' };
const money = (n) => `${Number(n).toLocaleString('vi-VN')}đ`;
const stamp = (ms) => `${new Date(ms).toLocaleTimeString('vi-VN', { ...TZ, hour12: false })} · ${new Date(ms).toLocaleDateString('vi-VN', TZ)}`;
const until = (ms) => (ms >= Number.MAX_SAFE_INTEGER ? 'vĩnh viễn' : new Date(ms).toLocaleString('vi-VN', TZ));
const maskName = (name) => (name.length <= 3 ? name : `${name.slice(0, 3)}***`);
const on = (cond) => (cond ? h` class="on"` : '');
const BANKS = ['MB Bank', 'Vietcombank', 'VietinBank', 'BIDV', 'Techcombank', 'ACB', 'VPBank', 'TPBank', 'Sacombank', 'Agribank', 'MSB', 'HDBank', 'VIB', 'SHB', 'OCB'];
const NAV = [['/', 'Trang chủ'], ['/task', 'Nhiệm vụ'], ['/withdraw', 'Rút tiền'], ['/friends', 'Bạn bè'], ['/more', 'Thêm']];

const CSS = `*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:#fff;color:#000;font:16px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,"Noto Sans",Arial,sans-serif;touch-action:manipulation}
main{max-width:560px;margin:0 auto;padding:8px 16px 104px}
header{display:flex;justify-content:space-between;align-items:center;padding:10px 0}
.logo{display:flex;gap:6px;align-items:center;font-size:24px;font-weight:800;color:#000;text-decoration:none}
.logo b{background:#000;color:#fff;border-radius:8px;padding:0 9px}
.hd{display:flex;gap:8px;align-items:center}.hd form{margin:0}
.pill{border:2px solid #000;border-radius:999px;padding:6px 16px;font-weight:800}
h1,h2{margin:0 0 6px;font-size:22px;line-height:1.25}p{margin:6px 0}a{color:#000}
.card{border:1px solid #e4e4e4;border-radius:22px;padding:18px;margin:14px 0}
.dark{background:#000;color:#fff;border-color:#000}.dark .mut{color:#bdbdbd}
.big{font-size:44px;font-weight:800;line-height:1.1;margin:8px 0}
.mut{color:#6b6b6b}.c{text-align:center}.err{font-weight:700}
.note{border:1px solid #000;border-radius:14px;padding:10px 14px;font-weight:700}
.lbl{font-weight:800;margin:14px 0 4px}
button,.btn{display:block;width:100%;margin:10px 0;padding:14px;border:1.5px solid #000;border-radius:14px;background:#000;color:#fff;font:inherit;font-weight:700;text-align:center;text-decoration:none;cursor:pointer}
.o{background:#fff;color:#000}
button.out{width:auto;margin:0;padding:9px 14px;border:1px solid #e4e4e4;background:#fff;color:#000;border-radius:12px}
button.sm{width:auto;margin:0;padding:6px 12px;font-size:14px}
.row{display:flex;gap:10px}.row>*{flex:1}
input,select{display:block;width:100%;margin:8px 0;padding:14px;border:1px solid #e4e4e4;border-radius:14px;background:#fff;color:#000;font:inherit}
input:focus,button:focus-visible,a:focus-visible{outline:2px solid #000;outline-offset:2px}
input[readonly]{user-select:all;background:#f4f4f4}
.hp{position:absolute;left:-9999px}
.seg,.f{display:flex;gap:6px;flex-wrap:wrap}
.seg{background:#f4f4f4;border-radius:16px;padding:6px;margin:14px 0}
.seg a{flex:1;text-align:center;padding:12px 4px;border-radius:12px;color:#555;font-weight:700;text-decoration:none}
.seg a.on,.f a.on{background:#000;color:#fff}
.f a{padding:9px 16px;border:1px solid #e4e4e4;border-radius:999px;font-weight:700;text-decoration:none;margin:4px 0}
.chips{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;position:relative}.chips.g3{grid-template-columns:repeat(3,1fr)}
.chips input{position:absolute;opacity:0;pointer-events:none}
.chips label{padding:14px 6px;text-align:center;border:1px solid #e4e4e4;border-radius:14px;font-weight:700;cursor:pointer}
.chips input:checked+label{background:#000;color:#fff;border-color:#000}
.chips input:focus-visible+label{outline:2px solid #000;outline-offset:2px}
.acc{display:flex;gap:10px;align-items:center;border:1px solid #e4e4e4;border-radius:16px;padding:12px;margin:8px 0}
.acc:has(input:checked){border-color:#000;background:#f4f4f4}
.acc input{width:auto;margin:0}.acc label{flex:1}
.tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.tile{background:#f4f4f4;border-radius:14px;padding:14px 4px;text-align:center;font-size:13px;color:#6b6b6b}.tile b{display:block;font-size:17px;color:#000}
.li{padding:12px 0;border-bottom:1px solid #eee}.li:last-child{border:0}
.top{display:flex;justify-content:space-between;gap:8px;align-items:center;font-weight:700}
.st{background:#000;color:#fff;border-radius:999px;padding:3px 12px;font-size:13px;white-space:nowrap}.st.w{background:#fff;color:#000;border:1px solid #000}
.rk{display:flex;gap:14px;padding:12px 8px;border-bottom:1px solid #eee}.rk span{flex:1}.rk.me{background:#f4f4f4;border-radius:12px}
.code{font:700 22px ui-monospace,Consolas,monospace;letter-spacing:3px;word-break:break-all}h1.code{text-align:center}
.scroll{overflow-x:auto}table{width:100%;border-collapse:collapse;font-size:14px}td,th{padding:8px 6px;border-bottom:1px solid #eee;text-align:left;vertical-align:top}
nav.tabs{position:fixed;left:0;right:0;bottom:0;display:flex;background:#fff;border-top:1px solid #e4e4e4;padding-bottom:env(safe-area-inset-bottom)}
nav.tabs a{flex:1;text-align:center;padding:15px 2px;color:#6b6b6b;font-size:14px;font-weight:700;text-decoration:none}
nav.tabs a.on{color:#000;box-shadow:inset 0 3px 0 #000}`;

module.exports = (CFG, SITE) => {
  const MSG = {
    ok_done: `Đúng mã! Đã cộng ${money(CFG.payout)}.`,
    ok_wd: 'Đã gửi yêu cầu, vui lòng chờ admin duyệt.',
    e_ban: 'Bạn đang bị cấm vượt link.',
    e_bot: 'Hệ thống nghi ngờ hành vi tự động nên yêu cầu bị từ chối.',
    e_limit: 'Bạn đã đạt giới hạn vượt link hôm nay.',
    e_dev: 'Mã phải được nhập trên đúng thiết bị đã vượt link.',
    e_code: 'Mã không đúng hoặc đã bị từ chối.',
    e_notask: 'Không có nhiệm vụ nào đang chờ.',
    e_wd: 'Thông tin rút không hợp lệ hoặc dưới mức tối thiểu.',
    e_bal: 'Số dư không đủ.',
    e_bank: 'Thông tin tài khoản không hợp lệ (tối đa 3 tài khoản).',
    e_short: 'Chưa tạo được link rút gọn, vui lòng thử lại sau ít phút.',
  };
  const flash = (key) => (Object.hasOwn(MSG, key) ? h`<p class="note">${MSG[key]}</p>` : '');

  const layout = (title, user, active, body, msg = '') => h`<!doctype html>
<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#ffffff"><title>${title} · VuotLink</title><link rel="stylesheet" href="/app.css"></head>
<body><main><header><a class="logo" href="/">VƯỢT <b>LINK</b></a>${user ? h`<div class="hd"><span class="pill">${money(user.balance)}</span><form method="post" action="/logout"><button class="out">Thoát</button></form></div>` : ''}</header>
${flash(msg)}${body}</main>
${user ? h`<nav class="tabs">${NAV.map(([href, label]) => h`<a href="${href}"${on(active === href)}>${label}</a>`)}</nav>` : ''}
</body></html>`;

  const authPage = (kind, err, ref = '') => {
    const login = kind === 'login';
    return layout(login ? 'Đăng nhập' : 'Đăng ký', null, '', h`<section class="card"><p class="mut">Vượt link · Nhận tiền · Rút tiền</p>
<div class="seg"><a href="/login"${on(login)}>Đăng nhập</a><a href="/register"${on(!login)}>Đăng ký</a></div>
${err ? h`<p class="note">${err}</p>` : ''}
<form method="post"><p class="lbl">Tên đăng nhập</p>
<input name="username" placeholder="3-20 ký tự: chữ, số, gạch dưới" required minlength="3" maxlength="20" autocomplete="username" autocapitalize="none">
<p class="lbl">Mật khẩu</p>
<input name="password" type="password" placeholder="Tối thiểu 8 ký tự" required minlength="8" maxlength="72" autocomplete="${login ? 'current-password' : 'new-password'}">
${login
    ? h`<p class="lbl">Mã 2FA <span class="mut">(chỉ dành cho owner)</span></p><input name="otp" inputmode="numeric" maxlength="6" autocomplete="one-time-code" placeholder="6 chữ số">`
    : h`<p class="lbl">Mã giới thiệu <span class="mut">(không bắt buộc)</span></p><input name="ref" value="${ref}" maxlength="12" placeholder="Nhập mã của người mời" autocomplete="off">`}
<button>${login ? 'Đăng nhập' : 'Tạo tài khoản'}</button></form>
${login ? '' : h`<p class="mut">Tài khoản mới cần admin duyệt trước khi đăng nhập.</p>`}</section>`);
  };

  const contactCard = () => (SITE.zalo || SITE.telegram
    ? h`<section class="card"><h2>Liên hệ admin</h2>${SITE.hours ? h`<p class="mut">${SITE.hours}</p>` : ''}<div class="row">${SITE.zalo ? h`<a class="btn o" href="https://zalo.me/${SITE.zalo}" rel="noopener">Zalo ${SITE.zalo}</a>` : ''}${SITE.telegram ? h`<a class="btn o" href="https://t.me/${SITE.telegram}" rel="noopener">Telegram</a>` : ''}</div></section>`
    : '');

  const homePage = (user, { today, total }, msg) => layout('Trang chủ', user, '/', h`
${SITE.notice ? h`<section class="card"><h2>Thông báo</h2><p class="mut">${SITE.notice}</p></section>` : ''}
<section class="card dark"><p class="mut">Xin chào, <b>${user.username}</b></p><div class="big">${money(user.balance)}</div>
<p class="mut">Hôm nay: <b>${today}</b> nhiệm vụ · +${money(CFG.payout)}/nv</p></section>
<div class="row"><a class="btn" href="/task">Làm nhiệm vụ</a><a class="btn o" href="/withdraw">Rút tiền</a></div>
<p class="mut c">Tổng hoàn thành: ${total} nhiệm vụ</p>
<section class="card"><h2>Mời bạn bè</h2><p class="mut">Nhận +${money(CFG.referralBonus)} cho mỗi bạn làm đủ ${CFG.referralAfter} nhiệm vụ.</p><a class="btn o" href="/friends">Xem mã giới thiệu</a></section>
${contactCard()}${user.role !== 'user' ? h`<a class="btn o" href="/admin">Quản trị</a>` : ''}`, msg);

  const taskPage = (user, task, today, msg) => {
    const action = user.banned_until > Date.now()
      ? h`<p class="note">Bạn bị cấm vượt link đến ${until(user.banned_until)}.</p>`
      : task
        ? h`<p>Còn <b>${Math.max(1, Math.ceil((task.expires_at - Date.now()) / 60_000))} phút</b> để nhập mã. Quá hạn sẽ bị cấm 24 giờ.</p>
<a class="btn" href="/go">Bắt đầu vượt link</a>
<form method="post" action="/code"><input class="hp" name="trap_9k" tabindex="-1" autocomplete="off" aria-hidden="true">
<input name="code" placeholder="Nhập mã sau khi vượt link" required maxlength="16" autocomplete="off" autocapitalize="characters"><button class="o">Xác nhận mã</button></form>`
        : h`<form method="post" action="/task"><button>Nhận nhiệm vụ mới</button></form>`;
    return layout('Nhiệm vụ', user, '/task', h`<section class="card"><h1>Nhiệm vụ</h1>
<p class="mut">Hôm nay ${today} · Thưởng ${money(CFG.payout)} · Hết hạn 20 phút</p>${action}</section>`, msg);
  };

  const statusOf = (w) => (w.status === 'pending' ? 'Chờ duyệt' : w.status === 'rejected' ? 'Từ chối' : w.method === 'bank' ? 'Đã chuyển' : 'Đã duyệt');
  const historyItem = (w) => {
    const parts = w.info.split(' · ');
    const title = w.method === 'bank' ? `Ngân hàng ${parts[0]}` : `Thẻ ${parts[0]}`;
    return h`<div class="li"><div class="top"><span>${title} · ${money(w.amount)}</span><span class="st${w.status === 'approved' ? '' : ' w'}">${statusOf(w)}</span></div>
<p class="mut">${w.method === 'bank' ? `${parts[1]} · ` : ''}${stamp(w.created_at)}</p>${w.note ? h`<p class="code">${w.note}</p>` : ''}</div>`;
  };
  const historyList = (rows) => (rows.length ? rows.map(historyItem) : h`<p class="mut">Chưa có yêu cầu nào.</p>`);

  const withdrawPage = (user, { tab, adding, banks, history }, msg) => {
    const hold = 'Tiền được giữ ngay khi gửi và hoàn lại nếu bị từ chối.';
    const cardForm = h`<form method="post" action="/withdraw"><input type="hidden" name="method" value="card">
<p class="lbl">Loại thẻ</p><div class="chips">${CFG.carriers.map((c, i) => h`<input type="radio" name="carrier" id="c${i}" value="${c}"${i === 0 ? h` checked` : ''}><label for="c${i}">${c}</label>`)}</div>
<p class="lbl">Mệnh giá</p><div class="chips g3">${CFG.cardDenoms.map((d, i) => h`<input type="radio" name="denom" id="d${i}" value="${d}"${i === 0 ? h` checked` : ''}><label for="d${i}">${money(d)}</label>`)}</div>
<button>Gửi yêu cầu đổi thẻ</button><p class="mut">Admin duyệt xong, mã thẻ và seri sẽ hiện ở Lịch sử bên dưới. ${hold}</p></form>`;
    const addForm = h`<form method="post" action="/bank"><p class="lbl">Thêm tài khoản nhận tiền</p>
<input name="bank" list="banks" placeholder="Ngân hàng (vd: MB Bank)" required maxlength="40" autocomplete="off">
<datalist id="banks">${BANKS.map((b) => h`<option value="${b}">`)}</datalist>
<input name="number" inputmode="numeric" placeholder="Số tài khoản" required pattern="[0-9 ]{6,24}" autocomplete="off">
<input name="holder" placeholder="Tên chủ tài khoản (không dấu)" required maxlength="50" autocomplete="off">
<button>Lưu tài khoản</button>${banks.length ? h`<a class="btn o" href="/withdraw?t=bank">Hủy</a>` : ''}</form>`;
    const bankForm = h`<form method="post" action="/withdraw"><input type="hidden" name="method" value="bank"><p class="lbl">Tài khoản nhận tiền</p>
${banks.map((b, i) => h`<div class="acc"><input type="radio" name="account" id="a${b.id}" value="${b.id}"${i === 0 ? h` checked` : ''}><label for="a${b.id}"><b>${b.bank} · ${b.number}</b><br><span class="mut">${b.holder}</span></label><button class="out" formaction="/bank/delete" formnovalidate name="bank_id" value="${b.id}">Xóa</button></div>`)}
${banks.length < 3 ? h`<a class="btn o" href="/withdraw?t=bank&amp;add=1">+ Thêm tài khoản</a>` : ''}
<p class="lbl">Số tiền muốn rút</p><input name="amount" type="number" inputmode="numeric" min="${CFG.bankMin}" step="1" placeholder="Tối thiểu ${money(CFG.bankMin)}" required>
<button>Gửi yêu cầu rút tiền</button><p class="mut">Admin chuyển khoản rồi duyệt. ${hold}</p></form>`;
    const form = tab === 'bank' ? (adding || !banks.length ? addForm : bankForm) : cardForm;
    return layout('Rút tiền', user, '/withdraw', h`<section class="card"><h1>Rút tiền</h1>
<p class="mut">Số dư ${money(user.balance)} · Tối thiểu ${money(tab === 'bank' ? CFG.bankMin : CFG.cardMin)}</p>
<div class="seg"><a href="/withdraw?t=card"${on(tab === 'card')}>Đổi thẻ cào</a><a href="/withdraw?t=bank"${on(tab === 'bank')}>Rút ngân hàng</a></div>${form}</section>
<section class="card"><h2>Lịch sử gần đây</h2>${historyList(history)}</section>`, msg);
  };

  const friendsPage = (user, { invited, link }, msg) => layout('Bạn bè', user, '/friends', h`<section class="card"><h1>Mời bạn bè</h1>
<p class="mut">Nhận +${money(CFG.referralBonus)} cho mỗi bạn làm đủ ${CFG.referralAfter} nhiệm vụ. Tài khoản cùng IP hoặc cùng thiết bị không được tính.</p>
<p class="lbl">Mã giới thiệu của bạn</p><p class="code">${user.ref_code ?? ''}</p>
<p class="lbl">Link giới thiệu</p><input value="${link}" readonly><p class="mut">Đã mời: <b>${invited}</b> bạn</p></section>`, msg);

  const morePage = (user, { tab, filter, sums, rows, ranks }, msg) => {
    const tabs = [['history', 'Lịch sử'], ['rank', 'Xếp hạng'], ['contact', 'Liên hệ']];
    const filters = [['all', 'Tất cả'], ['card', 'Thẻ cào'], ['bank', 'Ngân hàng'], ['pending', 'Chờ duyệt'], ['rejected', 'Từ chối']];
    let body;
    if (tab === 'rank') {
      body = h`<section class="card"><h2>Top 10 vượt link</h2>${ranks.map((r, i) => h`<div class="rk${r.username === user.username ? ' me' : ''}"><b>${i + 1}</b><span>${r.username === user.username ? r.username : maskName(r.username)}</span><b>${r.c}</b></div>`)}${ranks.length ? '' : h`<p class="mut">Chưa có dữ liệu.</p>`}</section>`;
    } else if (tab === 'history') {
      body = h`<section class="card"><h2>Tổng quan</h2><div class="tiles"><div class="tile"><b>${money(sums.card)}</b>Đã đổi thẻ</div><div class="tile"><b>${money(sums.bank)}</b>Đã rút ngân hàng</div><div class="tile"><b>${sums.pending}</b>Đang chờ</div></div></section>
<section class="card"><h2>Lịch sử rút tiền / đổi thẻ</h2><div class="f">${filters.map(([k, label]) => h`<a href="/more?t=history&amp;f=${k}"${on(filter === k)}>${label}</a>`)}</div>${historyList(rows)}</section>`;
    } else {
      body = h`${contactCard()}<section class="card"><h2>Quy định</h2><p class="mut">Mỗi nhiệm vụ hết hạn sau 20 phút; quá hạn không nhập mã sẽ bị cấm vượt link 24 giờ. Mã phải nhập trên đúng thiết bị và trình duyệt đã nhận nhiệm vụ. Dùng tool, bot hoặc nhiều tài khoản sẽ bị khoá.</p></section>`;
    }
    return layout('Thêm', user, '/more', h`<div class="seg">${tabs.map(([k, label]) => h`<a href="/more?t=${k}"${on(tab === k)}>${label}</a>`)}</div>${body}`, msg);
  };

  const adminPage = (user, stats, wds, users, logs, pending = []) => layout('Quản trị', user, '', h`
<section class="card"><h1>Quản trị</h1><div class="tiles"><div class="tile"><b>${stats.users}</b>Người dùng</div><div class="tile"><b>${stats.done}</b>Link xong 24h</div><div class="tile"><b>${money(stats.paid)}</b>Đã chi</div></div><p class="mut">Đang nợ user: ${money(stats.owed)}</p></section>
<section class="card"><h2>Đăng ký chờ duyệt (${pending.length})</h2>${pending.map((p) => h`<div class="li"><div class="top"><span>${p.username}</span><span class="mut">${stamp(p.created_at)}</span></div>
<p class="mut">IP ${p.reg_ip}${p.referrer ? ` · mời bởi ${p.referrer}` : ''}${p.same ? ` · ⚠ ${p.same} tài khoản khác cùng IP/thiết bị` : ''}</p>
<form method="post" action="/admin/users/${p.id}"><div class="row"><button name="action" value="approve">Duyệt</button><button class="o" name="action" value="reject">Từ chối</button></div></form></div>`)}${pending.length ? '' : h`<p class="mut">Không có đăng ký chờ.</p>`}</section>
<section class="card"><h2>Yêu cầu rút (${wds.length})</h2>${wds.map((w) => h`<div class="li"><div class="top"><span>#${w.id} ${w.username}${w.flags ? ` ⚠${w.flags}` : ''}</span><b>${money(w.amount)}</b></div>
<p class="mut">${w.method === 'card' ? 'Thẻ' : 'Ngân hàng'} · ${w.info}</p>
<form method="post" action="/admin/withdrawals/${w.id}"><input name="note" placeholder="Mã thẻ + seri hoặc ghi chú" maxlength="200"><div class="row"><button name="action" value="approve">Duyệt</button><button class="o" name="action" value="reject">Từ chối</button></div></form></div>`)}${wds.length ? '' : h`<p class="mut">Không có yêu cầu chờ.</p>`}</section>
<section class="card"><h2>Người dùng (nghi vấn lên đầu)</h2><div class="scroll"><table><tr><th>Tên</th><th>Số dư</th><th>Cờ</th><th></th></tr>
${users.map((u) => {
    const banned = u.banned_until > Date.now();
    return h`<tr><td>${u.username}<br><span class="mut">${u.role}${banned ? ` · cấm đến ${until(u.banned_until)}` : ''}</span></td><td>${money(u.balance)}</td><td>${u.flags}</td>
<td>${u.role === 'user' ? h`<form method="post" action="/admin/users/${u.id}"><button class="sm${banned ? '' : ' o'}" name="action" value="${banned ? 'unban' : 'ban'}">${banned ? 'Gỡ cấm' : 'Cấm'}</button></form>` : ''}</td></tr>`;
  })}</table></div></section>
<section class="card"><h2>Nhật ký nghi vấn</h2>${logs.map((l) => h`<div class="li"><div class="top"><span>${l.username}</span><span class="mut">${stamp(l.created_at)}</span></div><p class="mut">${l.reason} · ${l.ip}</p></div>`)}${logs.length ? '' : h`<p class="mut">Chưa có.</p>`}</section>`);

  return { h, send, CSS, layout, authPage, homePage, taskPage, withdrawPage, friendsPage, morePage, adminPage };
};
