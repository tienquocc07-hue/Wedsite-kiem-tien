'use strict';
// Gọi thử API Layma bằng token trong .env và in nguyên phản hồi để đối chiếu định dạng.
const token = process.env.LAYMA_TOKEN;
const base = (process.env.BASE_URL || '').replace(/\/$/, '');
if (!token || !base) {
  console.error('Cần LAYMA_TOKEN và BASE_URL trong .env');
  process.exit(1);
}
const query = new URLSearchParams({
  tokenUser: token, format: 'json', url: `${base}/cb/test`, link_du_phong: process.env.LAYMA_BACKUP_URL || `${base}/task`,
});
fetch(`https://api.layma.net/api/admin/shortlink/quicklink?${query}`, { signal: AbortSignal.timeout(8000) })
  .then(async (res) => console.log(res.status, (await res.text()).slice(0, 500).replaceAll(token, '***')))
  .catch((err) => {
    console.error('Lỗi:', err.message);
    process.exit(1);
  });
