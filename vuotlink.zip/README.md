# VuotLink

## Chạy thử
1. Cài Node.js ≥ 20.6 rồi chạy `npm install`.
2. `cp .env.example .env && chmod 600 .env`, điền `SECRET`, `OWNER_PASS` (≥ 12 ký tự), `OWNER_TOTP_SECRET` và `LAYMA_TOKEN` (cách tạo nằm trong `.env.example`).
3. Thêm khoá 2FA vào Google Authenticator: thêm khoá thủ công, loại theo thời gian.
4. `npm start`, vào `/login` bằng tài khoản owner kèm mã 2FA.
5. `npm run check:layma` để thử API Layma; nếu lỗi, gửi phản hồi in ra (đã che token) cho dev.

## Triển khai production (VPS Linux)
```bash
sudo useradd --system --home /opt/vuotlink --shell /usr/sbin/nologin vuotlink
sudo mkdir -p /opt/vuotlink && sudo cp -r . /opt/vuotlink && cd /opt/vuotlink
sudo npm install --omit=dev
sudo mkdir -p data && sudo chown vuotlink:vuotlink data && sudo chmod 700 data
sudo chown root:vuotlink .env && sudo chmod 640 .env
sudo cp deploy/vuotlink.service /etc/systemd/system/
sudo systemctl enable --now vuotlink
```
Mã nguồn thuộc root nên tiến trình web chỉ ghi được vào `data/`: dù app bị khai thác cũng không sửa được code hay cài web shell lâu dài.
Đặt `NODE_ENV=production`, `TRUST_PROXY=1`, `BASE_URL=https://tên-miền` trong `.env`, rồi cấu hình nginx theo `deploy/nginx.conf`.

## Sau khi chạy
- Giữ `package-lock.json` sinh ra sau lần `npm install` đầu và chạy `npm audit` định kỳ.
- Backup `data/data.db` hằng ngày, giữ bản sao ngoài máy chủ.

## Quản trị
- Đăng ký mới và yêu cầu rút tiền đều chờ admin duyệt tại `/admin`.
- Mỗi lượt vượt link tạo một link Layma riêng; lỗi API không bị tính là lỗi của người dùng.
