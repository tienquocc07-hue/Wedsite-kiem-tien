'use strict';
// File .db/-wal/-shm chỉ chủ tiến trình đọc được, tránh lộ số dư và hash mật khẩu.
process.umask(0o077);
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');

const env = process.env;
const need = (key) => {
  if (!env[key]) throw new Error(`Thiếu biến môi trường ${key}`);
  return env[key];
};
const int = (key, fallback) => Number.parseInt(env[key] ?? fallback, 10);

const PROD = env.NODE_ENV === 'production';
const BASE_URL = need('BASE_URL').replace(/\/$/, '');
const ORIGIN = new URL(BASE_URL).origin;
const SECRET = need('SECRET');
const LAYMA_TOKEN = env.LAYMA_TOKEN || '';
const BACKUP_URL = env.LAYMA_BACKUP_URL || `${BASE_URL}/task`;
const OWN_ORIGINS = new Set([ORIGIN, new URL(BACKUP_URL).origin]);
const SHORTENER_HOST = env.SHORTENER_HOST || '';
const ADMIN_IPS = (env.ADMIN_IPS || '').split(',').map((ip) => ip.trim()).filter(Boolean);
const RESERVED_NAMES = new Set(['admin', 'administrator', 'owner', 'root', 'support', 'system', (env.OWNER_USER || '').toLowerCase()]);
const OWNER_TOTP = env.OWNER_TOTP_SECRET || '';
if (SECRET.length < 32) throw new Error('SECRET phải có ít nhất 32 ký tự');
if (PROD && !LAYMA_TOKEN) throw new Error('Production yêu cầu LAYMA_TOKEN');
if (!LAYMA_TOKEN) console.warn('LAYMA_TOKEN trống: chế độ thử, link vượt trỏ thẳng vào trang nhận mã nên ai cũng bỏ qua được.');

const DAY = 86_400_000;
const FOREVER = Number.MAX_SAFE_INTEGER;
const CFG = {
  payout: int('PAYOUT', 250),
  taskMs: 20 * 60_000,
  banMs: DAY,
  minSeconds: int('MIN_SECONDS', 45),
  dailyUser: int('DAILY_LIMIT_USER', 100),
  dailyIp: int('DAILY_LIMIT_IP', 200),
  cardMin: 20_000,
  bankMin: 2_000,
  flagBan: 3,
  maxTries: 5,
  accountsPerDay: 3,
  referralAfter: 10,
  referralBonus: 1000,
  carriers: ['Garena', 'Viettel', 'Vinaphone', 'Vietnamobile'],
  cardDenoms: [20_000, 50_000, 100_000, 200_000, 500_000],
};
const SITE = {
  notice: env.NOTICE || '',
  zalo: (env.CONTACT_ZALO || '').replace(/\D/g, ''),
  telegram: (env.CONTACT_TELEGRAM || '').replace(/\W/g, ''),
  hours: env.CONTACT_HOURS || '',
};

const DB_FILE = env.DB_FILE || 'data/data.db';
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL COLLATE NOCASE, pass TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user', balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0),
  banned_until INTEGER NOT NULL DEFAULT 0, flags INTEGER NOT NULL DEFAULT 0,
  reg_ip TEXT, reg_did TEXT, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(sid TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS tasks(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, code TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
  did TEXT NOT NULL, ip TEXT NOT NULL, cb_did TEXT, cb_at INTEGER, tries INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS one_pending_task ON tasks(user_id) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS pending_expiry ON tasks(expires_at) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS tasks_by_ip ON tasks(ip, created_at);
CREATE TABLE IF NOT EXISTS withdrawals(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, method TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount > 0),
  info TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', note TEXT, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS flag_log(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, reason TEXT NOT NULL, ip TEXT, created_at INTEGER NOT NULL);
`);

const addColumn = (table, column, type) => {
  if (!db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`);
};
addColumn('users', 'ref_code', 'TEXT');
addColumn('users', 'referred_by', 'INTEGER');
addColumn('users', 'status', "TEXT NOT NULL DEFAULT 'active'");
addColumn('tasks', 'short_url', 'TEXT');
db.exec(`
CREATE UNIQUE INDEX IF NOT EXISTS users_ref_code ON users(ref_code);
CREATE INDEX IF NOT EXISTS tasks_done ON tasks(user_id) WHERE status = 'done';
CREATE TABLE IF NOT EXISTS bank_accounts(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, bank TEXT NOT NULL, number TEXT NOT NULL, holder TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS bank_accounts_user ON bank_accounts(user_id);
`);
const newRefCode = () => {
  let code;
  do {
    code = crypto.randomBytes(5).toString('hex').toUpperCase();
  } while (db.prepare('SELECT 1 FROM users WHERE ref_code = ?').get(code));
  return code;
};
for (const { id } of db.prepare('SELECT id FROM users WHERE ref_code IS NULL').all()) {
  db.prepare('UPDATE users SET ref_code = ? WHERE id = ?').run(newRefCode(), id);
}

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const sign = (id) => crypto.createHmac('sha256', SECRET).update(String(id)).digest('hex').slice(0, 24);
const safeEq = (a, b) => {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
const field = (req, key) => String(req.body[key] ?? '');

const DUMMY_HASH = bcrypt.hashSync('dummy-password', 11);
if (env.OWNER_PASS && env.OWNER_PASS.length < 12) throw new Error('OWNER_PASS phải có ít nhất 12 ký tự');

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const base32Decode = (text) => {
  let bits = '';
  for (const ch of text.replace(/=+$/, '').toUpperCase()) {
    const value = B32.indexOf(ch);
    if (value < 0) throw new Error('OWNER_TOTP_SECRET phải là chuỗi base32');
    bits += value.toString(2).padStart(5, '0');
  }
  return Buffer.from((bits.match(/.{8}/g) ?? []).map((byte) => Number.parseInt(byte, 2)));
};
const totp = (key, step) => {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const mac = crypto.createHmac('sha1', key).update(counter).digest();
  const offset = mac[19] & 0x0f;
  return String((mac.readUInt32BE(offset) & 0x7fffffff) % 1_000_000).padStart(6, '0');
};
const OWNER_KEY = OWNER_TOTP ? base32Decode(OWNER_TOTP) : null;
let lastTotpStep = 0;
// Mỗi mã chỉ dùng được một lần để kẻ nhìn trộm không phát lại mã vừa nhập.
const acceptOwnerOtp = (token) => {
  const now = Math.floor(Date.now() / 30_000);
  for (const step of [now - 1, now, now + 1]) {
    if (step > lastTotpStep && safeEq(totp(OWNER_KEY, step), token)) {
      lastTotpStep = step;
      return true;
    }
  }
  return false;
};
if (env.OWNER_USER && env.OWNER_PASS && !db.prepare("SELECT 1 FROM users WHERE role = 'owner'").get()) {
  db.prepare("INSERT INTO users(username, pass, role, created_at, ref_code) VALUES(?, ?, 'owner', ?, ?)")
    .run(env.OWNER_USER, bcrypt.hashSync(env.OWNER_PASS, 12), Date.now(), newRefCode());
}
if (PROD && !OWNER_KEY && db.prepare("SELECT 1 FROM users WHERE role = 'owner'").get()) {
  throw new Error('Production yêu cầu OWNER_TOTP_SECRET để bật 2FA cho owner');
}
if (!db.prepare("SELECT 1 FROM users WHERE role = 'owner'").get()) console.warn('Chưa có owner: đặt OWNER_USER và OWNER_PASS trong .env để có người duyệt đăng ký.');

// Phạt tính từ lúc hết hạn, không phải lúc phát hiện, để server tắt tạm không kéo dài án phạt.
const expirePending = db.transaction((now) => {
  const rows = db.prepare("SELECT id, user_id, expires_at FROM tasks WHERE status = 'pending' AND expires_at <= ?").all(now);
  for (const row of rows) {
    db.prepare("UPDATE tasks SET status = 'expired' WHERE id = ?").run(row.id);
    db.prepare('UPDATE users SET banned_until = MAX(banned_until, ?) WHERE id = ?').run(row.expires_at + CFG.banMs, row.user_id);
  }
});

const flagUser = db.transaction((userId, reason, ip) => {
  const now = Date.now();
  db.prepare('INSERT INTO flag_log(user_id, reason, ip, created_at) VALUES(?, ?, ?, ?)').run(userId, reason, ip, now);
  db.prepare('UPDATE users SET flags = flags + 1 WHERE id = ?').run(userId);
  db.prepare('UPDATE users SET banned_until = MAX(banned_until, ?) WHERE id = ? AND flags >= ?').run(now + CFG.banMs, userId, CFG.flagBan);
});

// Các câu UPDATE có điều kiện + transaction đồng bộ giúp không thể cộng/trừ tiền hai lần.
const completeTask = db.transaction((taskId, userId, now) => {
  const done = db.prepare("UPDATE tasks SET status = 'done' WHERE id = ? AND status = 'pending' AND expires_at > ?").run(taskId, now);
  if (done.changes !== 1) return false;
  db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(CFG.payout, userId);
  const finished = db.prepare("SELECT COUNT(*) AS c FROM tasks WHERE user_id = ? AND status = 'done'").get(userId).c;
  if (finished === CFG.referralAfter) {
    const friend = db.prepare(`SELECT u.reg_ip, u.reg_did, r.id AS rid, r.reg_ip AS rip, r.reg_did AS rdid
      FROM users u JOIN users r ON r.id = u.referred_by WHERE u.id = ? AND r.status = 'active'`).get(userId);
    // Cùng IP hoặc cùng thiết bị lúc đăng ký thì coi là tự mời nhau, không thưởng.
    if (friend && friend.reg_ip !== friend.rip && friend.reg_did !== friend.rdid) {
      db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(CFG.referralBonus, friend.rid);
    }
  }
  return true;
});

const createWithdrawal = db.transaction((userId, method, amount, info) => {
  const paid = db.prepare('UPDATE users SET balance = balance - ? WHERE id = ? AND balance >= ?').run(amount, userId, amount);
  if (paid.changes !== 1) return false;
  db.prepare('INSERT INTO withdrawals(user_id, method, amount, info, created_at) VALUES(?, ?, ?, ?, ?)')
    .run(userId, method, amount, info, Date.now());
  return true;
});

const settleWithdrawal = db.transaction((id, approve, note, actor) => {
  const w = db.prepare("SELECT * FROM withdrawals WHERE id = ? AND status = 'pending'").get(id);
  // Admin không tự duyệt yêu cầu rút của chính mình; chỉ owner được phép.
  if (!w || (w.user_id === actor.id && actor.role !== 'owner')) return;
  db.prepare('UPDATE withdrawals SET status = ?, note = ? WHERE id = ?').run(approve ? 'approved' : 'rejected', note, id);
  if (!approve) db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(w.amount, w.user_id);
});

const BOT_UA = /bot|crawl|spider|headless|phantom|selenium|puppeteer|playwright|curl|wget|python|httpclient|axios/i;
const botReason = (req) => {
  const ua = req.get('user-agent') || '';
  if (!ua || BOT_UA.test(ua)) return 'User-Agent nghi là bot';
  if (!req.get('accept-language')) return 'Thiếu Accept-Language';
  return null;
};

const { h, send, CSS, layout, authPage, homePage, taskPage, withdrawPage, friendsPage, morePage, adminPage } = require('./views')(CFG, SITE);

// Mốc 0h giờ Việt Nam để "hôm nay" khớp với người dùng, không trượt theo múi giờ máy chủ.
const dayStart = () => {
  const vn = new Date(Date.now() + 7 * 3_600_000);
  vn.setUTCHours(0, 0, 0, 0);
  return vn.getTime() - 7 * 3_600_000;
};

const limiter = (limit, windowMs = 60_000) => rateLimit({
  windowMs, limit, standardHeaders: true, legacyHeaders: false, message: 'Quá nhiều yêu cầu, vui lòng thử lại sau.',
});
const COOKIE = { httpOnly: true, sameSite: 'lax', secure: PROD };
const SESSION_MS = 7 * DAY;
const STAFF_SESSION_MS = 4 * 3_600_000;

const startSession = (res, userId, role = 'user') => {
  const ttl = role === 'user' ? SESSION_MS : STAFF_SESSION_MS;
  const sid = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(sid, user_id, expires_at) VALUES(?, ?, ?)').run(sha(sid), userId, Date.now() + ttl);
  res.cookie('sid', sid, { ...COOKIE, maxAge: ttl });
};
const needUser = (req, res, next) => (req.user ? next() : res.redirect('/login'));
const needAdmin = (req, res, next) => {
  const allowed = req.user && req.user.role !== 'user' && (!ADMIN_IPS.length || ADMIN_IPS.includes(req.ip));
  return allowed ? next() : res.status(403).send('Forbidden');
};

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', int('TRUST_PROXY', 0));
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'"],
      upgradeInsecureRequests: PROD ? [] : null,
    },
  },
}));
app.get('/app.css', (req, res) => res.type('css').set('Cache-Control', 'public, max-age=3600').send(CSS));
app.use(limiter(120));
app.use(express.urlencoded({ extended: false, limit: '4kb' }));
app.use(cookieParser());
app.use((req, res, next) => {
  req.body ??= {};
  if (req.method === 'POST') {
    // Sec-Fetch-Site do trình duyệt tự gắn và trang ngoài không giả được; Origin chỉ là dự phòng cho trình duyệt cũ.
    const site = req.get('sec-fetch-site');
    if (site ? site !== 'same-origin' : req.get('origin') !== ORIGIN) return res.status(403).send('Forbidden');
  }

  const did = String(req.cookies.did ?? '');
  req.did = /^[a-f0-9]{32}$/.test(did) ? did : crypto.randomBytes(16).toString('hex');
  if (req.did !== did) res.cookie('did', req.did, { ...COOKIE, maxAge: 365 * DAY });

  expirePending(Date.now());
  const sid = req.cookies.sid;
  req.user = sid
    ? db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.sid = ? AND s.expires_at > ? AND u.status = \'active\'').get(sha(String(sid)), Date.now())
    : undefined;
  res.set({ 'Cache-Control': 'no-store', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()' });
  next();
});

app.get(['/login', '/register'], (req, res) => (req.user ? res.redirect('/') : send(res, authPage(req.path.slice(1), null, String(req.query.ref ?? '')))));

app.post('/register', limiter(5, 3_600_000), async (req, res) => {
  const username = field(req, 'username');
  const password = field(req, 'password');
  const recent = db.prepare('SELECT COUNT(*) AS c FROM users WHERE (reg_ip = ? OR reg_did = ?) AND created_at > ?').get(req.ip, req.did, Date.now() - DAY).c;
  const error = !/^[a-zA-Z0-9_]{3,20}$/.test(username) ? 'Tên đăng nhập gồm 3-20 ký tự: chữ, số hoặc gạch dưới.'
    : RESERVED_NAMES.has(username.toLowerCase()) ? 'Tên đăng nhập này đã được hệ thống giữ.'
    : password.length < 8 || Buffer.byteLength(password) > 72 ? 'Mật khẩu phải từ 8 ký tự và tối đa 72 byte.'
      : recent >= CFG.accountsPerDay ? 'Thiết bị hoặc IP này đã đạt giới hạn tạo tài khoản hôm nay.'
        : null;
  if (error) return send(res, authPage('register', error, field(req, 'ref')), 400);
  try {
    const referrer = db.prepare("SELECT id FROM users WHERE ref_code = ? AND status = 'active'").get(field(req, 'ref').trim().toUpperCase());
    db.prepare("INSERT INTO users(username, pass, reg_ip, reg_did, created_at, ref_code, referred_by, status) VALUES(?, ?, ?, ?, ?, ?, ?, 'pending')")
      .run(username, await bcrypt.hash(password, 11), req.ip, req.did, Date.now(), newRefCode(), referrer ? referrer.id : null);
    return send(res, authPage('login', 'Đăng ký thành công! Tài khoản đang chờ admin duyệt, bạn đăng nhập được sau khi được duyệt.'), 201);
  } catch (err) {
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') return send(res, authPage('register', 'Tên đăng nhập đã tồn tại.', field(req, 'ref')), 409);
    throw err;
  }
});

// Khoá theo tài khoản (không chỉ theo IP) để chặn dò mật khẩu phân tán nhằm chiếm owner/admin.
const loginFails = new Map();
const LOCK = { maxFails: 10, windowMs: 900_000 };

app.post('/login', limiter(10, 900_000), async (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(field(req, 'username'));
  const fails = user && loginFails.get(user.id);
  if (fails && fails.count >= LOCK.maxFails && fails.until > Date.now()) {
    return send(res, authPage('login', 'Tài khoản tạm khoá đăng nhập do nhập sai nhiều lần, thử lại sau 15 phút.'), 429);
  }
  const passwordOk = await bcrypt.compare(field(req, 'password'), user ? user.pass : DUMMY_HASH);
  // Chỉ xét mã 2FA khi mật khẩu đúng, để kẻ dò mật khẩu không làm tiêu hao mã.
  const ok = Boolean(user) && passwordOk && (!OWNER_KEY || user.role !== 'owner' || acceptOwnerOtp(field(req, 'otp').trim()));
  if (!ok) {
    if (user) {
      const previous = fails && fails.until > Date.now() ? fails.count : 0;
      loginFails.set(user.id, { count: previous + 1, until: Date.now() + LOCK.windowMs });
    }
    return send(res, authPage('login', 'Sai tên đăng nhập hoặc mật khẩu.'), 401);
  }
  loginFails.delete(user.id);
  if (user.status !== 'active') {
    const reason = user.status === 'pending' ? 'Tài khoản đang chờ admin duyệt.' : 'Đăng ký của bạn đã bị từ chối.';
    return send(res, authPage('login', reason), 403);
  }
  startSession(res, user.id, user.role);
  return res.redirect('/');
});

app.post('/logout', (req, res) => {
  if (req.cookies.sid) db.prepare('DELETE FROM sessions WHERE sid = ?').run(sha(String(req.cookies.sid)));
  res.clearCookie('sid');
  res.redirect('/login');
});

const FILTERS = { all: '1 = 1', card: "method = 'card'", bank: "method = 'bank'", pending: "status = 'pending'", rejected: "status = 'rejected'" };
const countOne = (sql, ...args) => db.prepare(sql).get(...args).c;
const doneToday = (userId) => countOne("SELECT COUNT(*) AS c FROM tasks WHERE user_id = ? AND status = 'done' AND created_at >= ?", userId, dayStart());
const flashOf = (req) => String(req.query.m ?? '');
const queryOf = (req, key) => String(req.query[key] ?? '');

let rankCache = { at: 0, rows: [] };
// Bảng xếp hạng gom nhóm toàn bộ nhiệm vụ nên chỉ tính lại mỗi phút để trang luôn nhanh.
const topRanks = () => {
  if (Date.now() - rankCache.at > 60_000) {
    rankCache = {
      at: Date.now(),
      rows: db.prepare(`SELECT u.username, COUNT(*) AS c FROM tasks t JOIN users u ON u.id = t.user_id
        WHERE t.status = 'done' AND u.role = 'user' GROUP BY t.user_id ORDER BY c DESC, MIN(t.id) LIMIT 10`).all(),
    };
  }
  return rankCache.rows;
};

app.get('/', needUser, (req, res) => {
  const total = countOne("SELECT COUNT(*) AS c FROM tasks WHERE user_id = ? AND status = 'done'", req.user.id);
  send(res, homePage(req.user, { today: doneToday(req.user.id), total }, flashOf(req)));
});

app.get('/task', needUser, (req, res) => {
  const task = db.prepare("SELECT * FROM tasks WHERE user_id = ? AND status = 'pending'").get(req.user.id);
  send(res, taskPage(req.user, task, doneToday(req.user.id), flashOf(req)));
});

app.get('/withdraw', needUser, (req, res) => {
  const banks = db.prepare('SELECT * FROM bank_accounts WHERE user_id = ? ORDER BY id').all(req.user.id);
  const history = db.prepare('SELECT * FROM withdrawals WHERE user_id = ? ORDER BY id DESC LIMIT 5').all(req.user.id);
  const data = { tab: queryOf(req, 't') === 'bank' ? 'bank' : 'card', adding: queryOf(req, 'add') === '1', banks, history };
  send(res, withdrawPage(req.user, data, flashOf(req)));
});

app.get('/friends', needUser, (req, res) => {
  const invited = countOne("SELECT COUNT(*) AS c FROM users WHERE referred_by = ? AND status = 'active'", req.user.id);
  send(res, friendsPage(req.user, { invited, link: `${BASE_URL}/register?ref=${req.user.ref_code}` }, flashOf(req)));
});

app.get('/more', needUser, (req, res) => {
  const tab = ['rank', 'contact'].includes(queryOf(req, 't')) ? queryOf(req, 't') : 'history';
  const filter = Object.hasOwn(FILTERS, queryOf(req, 'f')) ? queryOf(req, 'f') : 'all';
  const data = { tab, filter };
  if (tab === 'history') {
    data.sums = db.prepare(`SELECT
      COALESCE(SUM(CASE WHEN method = 'card' AND status = 'approved' THEN amount END), 0) AS card,
      COALESCE(SUM(CASE WHEN method = 'bank' AND status = 'approved' THEN amount END), 0) AS bank,
      COALESCE(SUM(status = 'pending'), 0) AS pending
      FROM withdrawals WHERE user_id = ?`).get(req.user.id);
    data.rows = db.prepare(`SELECT * FROM withdrawals WHERE user_id = ? AND ${FILTERS[filter]} ORDER BY id DESC LIMIT 30`).all(req.user.id);
  }
  if (tab === 'rank') data.ranks = topRanks();
  send(res, morePage(req.user, data, flashOf(req)));
});

app.post('/task', needUser, limiter(10), async (req, res) => {
  const user = req.user;
  const now = Date.now();
  if (user.banned_until > now) return res.redirect('/task?m=e_ban');
  const bot = botReason(req);
  if (bot) {
    flagUser(user.id, bot, req.ip);
    return res.redirect('/task?m=e_bot');
  }
  const doneBy = (column, value) => db
    .prepare(`SELECT COUNT(*) AS c FROM tasks WHERE ${column} = ? AND status = 'done' AND created_at > ?`).get(value, dayStart()).c;
  if (doneBy('user_id', user.id) >= CFG.dailyUser || doneBy('ip', req.ip) >= CFG.dailyIp) return res.redirect('/task?m=e_limit');
  let taskId;
  try {
    taskId = db.prepare('INSERT INTO tasks(user_id, code, did, ip, created_at, expires_at) VALUES(?, ?, ?, ?, ?, ?)')
      .run(user.id, crypto.randomBytes(5).toString('hex').toUpperCase(), req.did, req.ip, now, now + CFG.taskMs).lastInsertRowid;
  } catch (err) {
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') return res.redirect('/task');
    throw err;
  }
  try {
    await attachShortLink(taskId);
  } catch (err) {
    // Lỗi phía nhà cung cấp không được phạt người dùng: huỷ nhiệm vụ để không dính án cấm do quá 20 phút.
    db.prepare("DELETE FROM tasks WHERE id = ? AND status = 'pending'").run(taskId);
    console.error('Tạo link rút gọn lỗi:', err.message);
    return res.redirect('/task?m=e_short');
  }
  return res.redirect('/task');
});

// Dùng link <a> (GET) thay vì form để CSP form-action không chặn redirect sang trang rút gọn bên ngoài.
app.get('/go', needUser, async (req, res) => {
  const task = db.prepare("SELECT id, short_url FROM tasks WHERE user_id = ? AND status = 'pending'").get(req.user.id);
  if (!task || req.user.banned_until > Date.now()) return res.redirect('/task');
  try {
    return res.redirect(task.short_url || await attachShortLink(task.id));
  } catch (err) {
    console.error('Tạo link rút gọn lỗi:', err.message);
    return res.redirect('/task?m=e_short');
  }
});

const callbackUrl = (taskId) => `${BASE_URL}/cb/${taskId}.${sign(taskId)}`;
const SHORT_KEYS = ['shortenedUrl', 'shortened_url', 'shortUrl', 'short_url', 'shortlink', 'link', 'url', 'data', 'result'];
const externalUrl = (text) => {
  try {
    const url = new URL(text.trim());
    return ['http:', 'https:'].includes(url.protocol) && !OWN_ORIGINS.has(url.origin) ? url.href : null;
  } catch {
    return null;
  }
};
// Định dạng phản hồi của Layma chưa có tài liệu nên đọc linh hoạt; link thuộc tên miền của mình bị loại để không bao giờ trả lại chính callback.
const findLink = (value, depth = 0) => {
  if (typeof value === 'string') return externalUrl(value);
  if (!value || typeof value !== 'object' || depth > 3) return null;
  for (const key of [...SHORT_KEYS, ...Object.keys(value)]) {
    const found = key in value ? findLink(value[key], depth + 1) : null;
    if (found) return found;
  }
  return null;
};
const apiFailed = (data) => typeof data === 'object' && data !== null
  && (['error', 'fail', 'failed'].includes(String(data.status ?? '').toLowerCase())
    || data.success === false
    || Boolean(data.error && !['0', 'false'].includes(String(data.error))));

const createShortLink = async (taskId) => {
  const callback = callbackUrl(taskId);
  if (!LAYMA_TOKEN) return callback;
  const query = new URLSearchParams({ tokenUser: LAYMA_TOKEN, format: 'json', url: callback, link_du_phong: BACKUP_URL });
  const response = await fetch(`https://api.layma.net/api/admin/shortlink/quicklink?${query}`, { signal: AbortSignal.timeout(8_000) });
  const body = await response.text();
  let data = body;
  try {
    data = JSON.parse(body);
  } catch {
    // Phản hồi dạng text thuần vẫn được chấp nhận.
  }
  const link = response.ok && !apiFailed(data) ? findLink(data) : null;
  if (!link) throw new Error(`Layma phản hồi không dùng được (HTTP ${response.status}): ${body.slice(0, 300).replaceAll(LAYMA_TOKEN, '***')}`);
  return link;
};

const attachShortLink = async (taskId) => {
  const link = await createShortLink(taskId);
  db.prepare('UPDATE tasks SET short_url = ? WHERE id = ? AND short_url IS NULL').run(link, taskId);
  return link;
};

app.get('/cb/:token', limiter(30), (req, res) => {
  const [id, sig = ''] = req.params.token.split('.');
  if (!/^\d{1,12}$/.test(id) || !safeEq(sig, sign(id))) return res.status(400).send('Link không hợp lệ');
  const task = db.prepare("SELECT * FROM tasks WHERE id = ? AND status = 'pending' AND expires_at > ?").get(Number(id), Date.now());
  const deny = (message, reason) => {
    if (task && reason) flagUser(task.user_id, reason, req.ip);
    return send(res, layout('Từ chối', req.user, '/task', h`<section class="card"><p class="err">${message}</p><a href="/task">Về trang chủ</a></section>`), 403);
  };
  if (!task) return deny('Link đã hết hạn hoặc không tồn tại.');
  if (botReason(req)) return deny('Yêu cầu bị từ chối.');
  if (req.did !== task.did) return deny('Hãy mở link trên đúng thiết bị và trình duyệt đã tạo link.', 'Nhận mã trên thiết bị khác');
  if (SHORTENER_HOST && !(req.get('referer') || '').includes(SHORTENER_HOST)) return deny('Bạn chưa hoàn thành link rút gọn.', 'Bỏ qua trang rút gọn');
  const wait = CFG.minSeconds - Math.floor((Date.now() - task.created_at) / 1000);
  if (wait > 0) return deny(`Bạn vượt link quá nhanh, hãy thử lại sau ${wait} giây.`);
  db.prepare('UPDATE tasks SET cb_did = ?, cb_at = COALESCE(cb_at, ?) WHERE id = ?').run(req.did, Date.now(), task.id);
  return send(res, layout('Mã của bạn', req.user, '/task', h`<section class="card"><p>Mã của bạn (nhập trên chính thiết bị này):</p>
<h1 class="code">${task.code}</h1><a class="btn" href="/task">Về trang nhập mã</a></section>`));
});

app.post('/code', needUser, limiter(20), (req, res) => {
  const user = req.user;
  if (field(req, 'trap_9k')) {
    flagUser(user.id, 'Điền vào ô bẫy bot', req.ip);
    return res.redirect('/task?m=e_bot');
  }
  const task = db.prepare("SELECT * FROM tasks WHERE user_id = ? AND status = 'pending'").get(user.id);
  if (!task) return res.redirect('/task?m=e_notask');
  const reject = (reason, m) => {
    db.prepare("UPDATE tasks SET status = 'rejected' WHERE id = ?").run(task.id);
    flagUser(user.id, reason, req.ip);
    return res.redirect(`/task?m=${m}`);
  };
  if (req.did !== task.did || (task.cb_did && task.cb_did !== req.did)) return reject('Nhập mã từ thiết bị khác', 'e_dev');
  const matches = task.cb_at && safeEq(field(req, 'code').trim().toUpperCase(), task.code);
  if (!matches) {
    if (task.tries + 1 >= CFG.maxTries) return reject('Nhập sai mã nhiều lần', 'e_code');
    db.prepare('UPDATE tasks SET tries = tries + 1 WHERE id = ?').run(task.id);
    return res.redirect('/task?m=e_code');
  }
  return res.redirect(completeTask(task.id, user.id, Date.now()) ? '/task?m=ok_done' : '/task?m=e_notask');
});

app.post('/withdraw', needUser, limiter(5), (req, res) => {
  const method = field(req, 'method') === 'bank' ? 'bank' : 'card';
  let amount = 0;
  let info = null;
  if (method === 'card') {
    const carrier = field(req, 'carrier');
    amount = Number(field(req, 'denom'));
    if (CFG.carriers.includes(carrier) && CFG.cardDenoms.includes(amount)) info = carrier;
  } else {
    const account = db.prepare('SELECT * FROM bank_accounts WHERE id = ? AND user_id = ?').get(Number(field(req, 'account')) || 0, req.user.id);
    amount = Number(field(req, 'amount'));
    if (account && Number.isSafeInteger(amount) && amount >= CFG.bankMin) info = `${account.bank} · ${account.number} · ${account.holder}`;
  }
  if (!info) return res.redirect(`/withdraw?t=${method}&m=e_wd`);
  return res.redirect(`/withdraw?t=${method}&m=${createWithdrawal(req.user.id, method, amount, info) ? 'ok_wd' : 'e_bal'}`);
});

app.post('/bank', needUser, limiter(10), (req, res) => {
  const bank = field(req, 'bank').replace(/·/g, ' ').trim().slice(0, 40);
  const number = field(req, 'number').replace(/\s/g, '');
  const holder = field(req, 'holder').replace(/·/g, ' ').trim().toUpperCase().slice(0, 50);
  const saved = countOne('SELECT COUNT(*) AS c FROM bank_accounts WHERE user_id = ?', req.user.id);
  if (bank.length < 2 || !/^\d{6,20}$/.test(number) || holder.length < 3 || saved >= 3) return res.redirect('/withdraw?t=bank&m=e_bank');
  db.prepare('INSERT INTO bank_accounts(user_id, bank, number, holder, created_at) VALUES(?, ?, ?, ?, ?)').run(req.user.id, bank, number, holder, Date.now());
  return res.redirect('/withdraw?t=bank');
});

app.post('/bank/delete', needUser, limiter(10), (req, res) => {
  db.prepare('DELETE FROM bank_accounts WHERE id = ? AND user_id = ?').run(Number(field(req, 'bank_id')) || 0, req.user.id);
  res.redirect('/withdraw?t=bank');
});

app.get('/admin', needAdmin, (req, res) => {
  const stats = db.prepare(`SELECT
    (SELECT COUNT(*) FROM users WHERE status = 'active') AS users,
    (SELECT COUNT(*) FROM tasks WHERE status = 'done' AND created_at > ?) AS done,
    (SELECT COALESCE(SUM(amount), 0) FROM withdrawals WHERE status = 'approved') AS paid,
    (SELECT COALESCE(SUM(balance), 0) FROM users) AS owed`).get(Date.now() - DAY);
  const wds = db.prepare(`SELECT w.*, u.username, u.flags FROM withdrawals w JOIN users u ON u.id = w.user_id
    WHERE w.status = 'pending' ORDER BY w.id LIMIT 100`).all();
  const users = db.prepare("SELECT * FROM users WHERE status = 'active' ORDER BY flags DESC, id DESC LIMIT 100").all();
  const logs = db.prepare('SELECT l.*, u.username FROM flag_log l JOIN users u ON u.id = l.user_id ORDER BY l.id DESC LIMIT 30').all();
  const pending = db.prepare(`SELECT u.id, u.username, u.reg_ip, u.created_at, r.username AS referrer,
    (SELECT COUNT(*) FROM users o WHERE o.id <> u.id AND (o.reg_ip = u.reg_ip OR o.reg_did = u.reg_did)) AS same
    FROM users u LEFT JOIN users r ON r.id = u.referred_by WHERE u.status = 'pending' ORDER BY u.id LIMIT 100`).all();
  send(res, adminPage(req.user, stats, wds, users, logs, pending));
});

app.post('/admin/withdrawals/:id', needAdmin, (req, res) => {
  settleWithdrawal(Number(req.params.id), field(req, 'action') === 'approve', field(req, 'note').slice(0, 200), req.user);
  res.redirect('/admin');
});

app.post('/admin/users/:id', needAdmin, (req, res) => {
  const id = Number(req.params.id) || 0;
  const action = field(req, 'action');
  if (action === 'approve') {
    db.prepare("UPDATE users SET status = 'active' WHERE id = ? AND role = 'user' AND status <> 'active'").run(id);
  } else if (action === 'reject') {
    db.prepare("UPDATE users SET status = 'rejected' WHERE id = ? AND role = 'user' AND status = 'pending'").run(id);
  } else if (action === 'ban' || action === 'unban') {
    const until = action === 'ban' ? FOREVER : 0;
    db.prepare("UPDATE users SET banned_until = @until, flags = CASE WHEN @until = 0 THEN 0 ELSE flags END WHERE id = @id AND role = 'user'")
      .run({ until, id });
  }
  res.redirect('/admin');
});

app.use((req, res) => res.status(404).send('Không tìm thấy trang'));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send('Lỗi hệ thống');
});

setInterval(() => {
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
  expirePending(Date.now());
}, 60_000).unref();

const server = app.listen(int('PORT', 3000), env.HOST || '127.0.0.1', () => console.log(`Đang chạy tại ${BASE_URL}`));
// Cắt kết nối gửi header/body chậm (slowloris) để không chiếm hết socket.
server.headersTimeout = 15_000;
server.requestTimeout = 20_000;
server.keepAliveTimeout = 5_000;
process.on('SIGTERM', () => server.close(() => {
  db.close();
  process.exit(0);
}));
